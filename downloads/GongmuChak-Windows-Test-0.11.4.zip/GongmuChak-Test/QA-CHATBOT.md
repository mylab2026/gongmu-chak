# 챗봇 지원 변경 검증

기준 브랜치: claude/step4-sticky-overlap, 676606823a5425f62e3a11b7fcfea9572a29b011.
지원 빌드: 0.11.2-test / chatbot-support.1. 새 작업 브랜치: codex/chatbot-support-handoff.

## 로컬 합성자료 검증
- Python 3.12.14: unittest 전체 194개 실행, 성공, Windows 전용 3개 건너뜀. 이 환경에는 Python 3.14 실행기가 없어 저장소 CI의 3.14 검사를 별도로 확인해야 한다.
- 새 검사 7개: 프로젝트 없는 상담, 사업 선택만으로 목록 수집하지 않음, 포함 동의 시 파일 바이트/설정 불변, 본문/키 미포함, 누락 경로의 명시적 부분 보고, 인증정보 가림, 잘못된 입력.
- node test_ui.cjs 및 node test_revision_ui.cjs 성공. chatbot-support.js 구문 검사 성공.
- 로컬 Chromium 실제 화면 검사는 socket() Operation not permitted로 브라우저 시작 단계에서 막힘. 통과로 표시하지 않음.
- tools/browser_smoke.py에 실제 상담 대화상자, 체크 전후 정보 포함과 기존 결과 무효화, 미리보기 수정 후 TXT 다운로드, 문서 불변 검사를 추가.

## GitHub CI 후속 확인
- 첫 수정 커밋 bf84fc7의 Linux Python 3.14·Node·브라우저·패키징 검사 통과.
- Windows에서 기존 검사 두 개 실패: 예시 폴더 경로의 8.3/정규 경로 비교 차이, 실패 이력에 8.3 절대 경로 잔존.
- 폴더 검사는 양쪽 경로를 정규화해 비교하도록 보정. 이력 내보내기는 다른 표기의 Windows 절대 경로와 UNC 경로도 가리고 상대 경로는 유지하도록 보완. OS 독립 회귀 검사 추가. 후속 커밋의 CI 결과는 해당 브랜치 Actions 기록에서 확인.
- 보완 후 로컬 Python 전체 195개 실행 성공(Windows 전용 3개 건너뜀).
- 0534ba2에서 Windows Python 3.14 195개 및 Node 검사 통과. 이어진 패키징에서 챗봇 하위 폴더의 경로 구분자 차이가 발견되어 ZIP 목록을 POSIX 경로로 통일.

## 미검증/운영 작업
- 실제 직원 PC, 업무 원본, 전체 Windows 설치/업데이트 실행, DPAPI/.lnk 실환경은 이 로컬 환경에서 검증하지 않음.
- 학내 챗봇에 프롬프트를 등록하거나 모델에 실제 상담을 호출하지 않음. ACCEPTANCE.md로 운영자가 검수해야 함.
- 설치본 승인 URL, 챗봇 URL, 담당 지원 연락처는 제공되지 않아 카탈로그를 비워 둠. 링크를 임의 생성하지 않음.
- 자동 가림은 모든 업무정보/임의 비밀 형식을 보장하지 않음. 미리보기 후 사용자 검토/삭제가 필요.
- 상담자료와 이력 ZIP은 원본 문서 백업이나 자동 복구 파일이 아님.
